import React, { Component } from 'react';
import ProductDisplay from './ProductDisplay';
import { BrowserRouter as Router, Route, Link } from "react-router-dom";
import ProductDetails from './ProductDetails';
class ProductList extends Component {
    constructor(props) {
        super(props);
        this.state={
            q:'',
            pId:'',
            m1:'',
            m2:'',
            productList :[
                {
                    
                    productId: 1001,
                    productName: 'Watch',
                    quantityOnHand: 2000,
                    price: 10000
                },
                {
                    productId: 1002,
                    productName: 'Mouse',
                    quantityOnHand: 29,
                    price: 180000
                },
                {
                    productId: 1003,
                    productName: 'Laptop',
                    quantityOnHand: 29,
                    price: 122
                },
                {
                    productId: 10113,
                    productName: 'Presenter',
                    quantityOnHand: 29,
                    price: 122
                },
    
                {
                    productId: 111003,
                    productName: 'Marker',
                    quantityOnHand: 29,
                    price: 122
                },
            ]
            
        }
        this.handleChange1=this.handleChange1.bind(this)
        this.handleChange2=this.handleChange2.bind(this)
        this.handleSubmit=this.handleSubmit.bind(this)
        //this.updateComment=this.updateComment.bind(this)
    }

    handleChange1(e1)
    {
        this.setState({
            pId:e1.target.value
        })
    }
    
     handleChange2(e2)
     {
        this.setState({
            q:e2.target.value
        })
         /* if(this.state.>0)
         {
             this.setState({
                 q:e2.target.value
             })
         } */
    }  
        
    
    handleSubmit(e2)
    {
        if(this.state.m1="successfully added")
        {
            this.setState({
                q:e2.target.value
            })
        }
        if(this.state.q<0){
            this.setState({
                m1:"cannot be negative"
            })
        }
        if(this.state.q==''){
            this.setState({
                m1:"cannot be empty"
            })
        }
        if(this.state.q>0){
            this.setState({
                m1:"successfully added"
            })
        }
        
        
        
    }
    /* updateComment(q, pId){
        
            var arr = this.state.pId
              arr[pId] = q
          this.setState({pId:arr})
        } */
    
   
    
    render() {
        const productList =[
            {
                
                productId: 1001,
                productName: 'Watch',
                quantityOnHand: 2000,
                price: 10000
            },
            {
                productId: 1002,
                productName: 'Mouse',
                quantityOnHand: 29,
                price: 180000
            },
            {
                productId: 1003,
                productName: 'Laptop',
                quantityOnHand: 29,
                price: 122
            },
            {
                productId: 10113,
                productName: 'Presenter',
                quantityOnHand: 29,
                price: 122
            },

            {
                productId: 111003,
                productName: 'Marker',
                quantityOnHand: 29,
                price: 122
            },
        ]
        if(this.state.pId==productList.productId)
        

        
        
        return (
            <div>
                <h1>Product Details Here</h1>
                <input type="text" value={this.state.pId}  onChange={this.handleChange1}/>
               
                <input type="text" name={this.state.q}  onChange={this.handleChange2}/>
                {this.state.m1}
                <button onClick={this.handleSubmit}>Add</button>
               
                {/* {productList.map((product, index) =>
                    <Link to={`${this.props.match.url}/`+product.productName}>
                        <ProductDisplay render={({ match }) => match={match}}
                            nn={index}
                            key={index}
                            product={product}
                        ></ProductDisplay>
                    </Link>

                )}

                <Route path={`${this.props.match.path}/:productName`}
                    render={({ match }) => match={match}} 
                    component={ProductDetails} /> */}
                    
            {productList.map((product,index)=>
                    
                        
                    <ProductDisplay nn={index} key={index} product={product} id={this.state.pId} qOH={this.state.q} ></ProductDisplay>
                )}
                
                
                
                
                
            </div>

        );
    }
}
export default ProductList;
