import React, { Component } from 'react';

class searchProductComponent extends Component {
    constructor(props) {
        super(props);
        this.state={
            productName:''
        }
        this.handleSubmit = this.handleSubmit.bind(this)
        this.handleChange = this.handleChange.bind(this)
    }
    handleChange(e){
        e.preventDefault()
        this.setState({
            productName:e.target.value
        })
    }
    handleSubmit(){
        console.log(this.state.productName)
        this.props.history.push(`/productsNameList/${this.state.productName}`) 
    }

    
    render() {
        return (
            <form className="form-group">
            <div className="container">                
                Product Name:<input type="text" value={this.state.productName} onChange={this.handleChange} className="form-control"/>
                <button className="btn btn-success" onClick={this.handleSubmit}>Submit</button>
            </div>
            </form>
        );
    }

}
export default searchProductComponent;