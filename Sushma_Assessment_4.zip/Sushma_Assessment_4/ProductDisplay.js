import React, { Component } from 'react';

class ProductDisplay extends Component {
    
    render() {
        const {nn,product,id,qOH} = this.props
        if(id===product.productId)
        {
            return (
                <div>
                    
                    <h3>
                        key:{nn}
                        
                        Product Id :  {product.productId} &nbsp; &nbsp;
                        Product Name :    {product.productName} &nbsp; &nbsp;
                        QuantityOnHand : {qOH} &nbsp; &nbsp;
                        
                        Price : {product.price}</h3> 
                        
                </div>
            );
        }
        else{
            return (
                <div>
                    
                    <h3>
                        key:{nn}
                        
                        Product Id :  {product.productId} &nbsp; &nbsp;
                        Product Name :    {product.productName} &nbsp; &nbsp;
                        QuantityOnHand : {product.quantityOnHand} &nbsp; &nbsp;
                        
                        Price : {product.price}</h3> 
                        
                </div>
            );
        }
        
        
    }
}

export default ProductDisplay;