import React, { Component } from 'react';
import ProductList from './ProductList'

class ProductStockUpdate extends Component {
    constructor(props) {
        super(props);
       
    }
    
    
    render() {
        return (
            <div>

                <ProductList></ProductList>
            </div>
        );
    }
}

export default ProductStockUpdate;

