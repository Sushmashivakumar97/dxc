import React, { Component } from 'react';
import ProductDataService from '../service/ProductDataService';
//import { thisExpression } from '@babel/types';
import { Formik, Form, Field, ErrorMessage } from 'formik'

class ProductComponent extends Component {
    constructor(props) {
        super(props);
        this.state = {
            productId: this.props.match.params.prodId,
            productName: '',
            quantityOnHand: '',
            price: '',
            btnText: 'ADD',
            disabled: false
        }
        this.onSubmit = this.onSubmit.bind(this)
    }
    componentWillMount() {
        if (!this.state.productId) { return; }

        ProductDataService.getProduct(this.state.productId).then(
            response => {
                
                this.setState({
                    productName: response.data.productName,
                    quantityOnHand: response.data.quantityOnHand,
                    price: response.data.price,
                    btnText: 'Update',
                    disabled: true
                })
            }
        )
        /* if(!this.state.productId)
       {
           this.setState({
               btnText:'Save'
           })
       }  */



    }
    onSubmit(product) {
        console.log(product)
        if (this.state.productId)
            ProductDataService.updateProduct(product).then(response => { this.props.history.push("/products") })
        else {
            ProductDataService.addProduct(product).then((response) => { this.props.history.push("/products") })
        }
    }
    validateProductForm(values) {
        let errors = {}
        if (!values.productId) {
            errors.productId = 'enter a productname'
        }
        else if (!values.productName) {
            errors.productName = 'enter a productname'
        }
        else if (!values.quantityOnHand) {
            errors.quantityOnHand = 'enter a quantity'
        }
        else if (!values.price) {
            errors.price = 'enter a price'
        }
        else if (values.productName.length < 3) {
            errors.productName = 'enter name with atelast 3 characters'
        }
        else if (values.price < 0) {
            errors.price = 'cannot be negative'
        }

        return errors
    }

    render() {
        let { productId, productName, quantityOnHand, price } = this.state
        //var add = this.state.productId
        return (
            <div>
                <div className="container">
                    <h1>ADD/UPDATE</h1>
                    
                    {/* <div>{productId}</div>
                <div>{productName}</div>
                <div>{quantityOnHand}</div>
                <div>{price}</div> */}
                    <Formik
                        initialValues={{ productId, productName, quantityOnHand, price }}
                        enableReinitialize={true}
                        onSubmit={this.onSubmit}
                        validateOnChange={false}
                        validateOnBlur={false}
                        validate={this.validateProductForm}>
                        <Form >
                            <ErrorMessage name="productId" component="div" className="alert alert-warning" />
                            <ErrorMessage name="productName" component="div" className="alert alert-warning" />
                            <ErrorMessage name="quantityOnHand" component="div" className="alert alert-warning" />
                            <ErrorMessage name="price" component="div" className="alert alert-warning" />


                            {/* {add?<fieldset className="form-group">
                        <label>product Id</label>
                        <Field className="form-control" type="text" name="productId" disabled/>
                        </fieldset>:
                        <fieldset className="form-group">
                        <label>product Id</label>
                        <Field className="form-control" type="text" name="productId"/>
                        </fieldset>
                         }    */}

                            <fieldset className="form-group">
                                <label>product Id</label>
                                <Field className="form-control" type="text" name="productId" disabled={this.state.disabled} />
                            </fieldset>
                            <fieldset className="form-group">
                                <label>product Name</label>
                                <Field className="form-control" type="text" name="productName" />
                            </fieldset>
                            <fieldset className="form-group">
                                <label>quantityOnHand</label>
                                <Field className="form-control" type="text" name="quantityOnHand" />
                            </fieldset>
                            <fieldset className="form-group">
                                <label>price</label>
                                <Field className="form-control" type="text" name="price" />
                            </fieldset>
                            <button className="btn btn-success" type="submit">{this.state.btnText}</button>
                        </Form>
                    </Formik>
                </div>
            </div>
        );
    }
}

export default ProductComponent;