package com.students.service;

import java.util.List;


import com.students.model.Students;

public interface StudentService {
	public boolean addStudent(Students student);
	public Students getStudent(int studentId);
	public boolean isStudentExists(int studentId);
	public boolean deleteStudent(int studentId);
	public boolean updateStudent(Students student);
	public List<Students> getAllStudents();
	public List<Students> getStudentByName(String studentName);

}
