package com.students.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.students.dao.StudentDAO;
import com.students.model.Students;

@Service
public class StudentServiceImpl implements StudentService {
	@Autowired
	StudentDAO studentDAO;
	
	@Override
	public boolean addStudent(Students student) {
		
		return studentDAO.addStudent(student);
	}

	@Override
	public Students getStudent(int studentId) {
		System.out.println("servie"+studentId);
		return studentDAO.getStudent(studentId);
	}

	@Override
	public boolean isStudentExists(int studentId) {
		
		return studentDAO.isStudentExists(studentId);
	}

	@Override
	public boolean deleteStudent(int studentId) {
		
		return studentDAO.deleteStudent(studentId);
	}

	@Override
	public boolean updateStudent(Students student) {
		
		return studentDAO.updateStudent(student);
	}

	@Override
	public List<Students> getAllStudents() {
		
		return studentDAO.getAllStudents();
	}

	@Override
	public List<Students> getStudentByName(String studentName) {
		
		return studentDAO.getStudentByName(studentName);
	}

}
