package com.students.dao;

import java.util.List;

import com.students.model.Students;

public interface StudentDAO {
	public boolean addStudent(Students student);
	public Students getStudent(int StudentId);
	public boolean isStudentExists(int StudentId);
	public boolean deleteStudent(int StudentId);
	public boolean updateStudent(Students Student);
	public List<Students> getAllStudents();
	public List<Students> getStudentByName(String StudentName);

}
