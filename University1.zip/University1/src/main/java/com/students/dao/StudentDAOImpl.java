package com.students.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;

import com.mongodb.WriteResult;
import com.mongodb.client.result.DeleteResult;
import com.mongodb.client.result.UpdateResult;
import com.students.model.Students;

@Repository
public class StudentDAOImpl implements StudentDAO {
	@Autowired
	MongoTemplate mongoTemplate;

	@Override
	public boolean addStudent(Students student) {
		mongoTemplate.save(student);
		return false;
	}

	@Override
	public Students getStudent(int studentId) {
		System.out.println("DAO" +studentId);
		
		return mongoTemplate.findById(studentId, Students.class, "students");
	}

	@Override
	public boolean isStudentExists(int studentId) {
		System.out.println("check"+studentId);
		Students student=new Students();
		student=mongoTemplate.findById(studentId, Students.class, "students");
		System.out.println(studentId);
		System.out.println(student);
		if(student==null) {
			System.out.println("false");
			return false;
		}
		else {
			System.out.println("true");
			return true;
		}
	}

	@Override
	public boolean deleteStudent(int studentId) {
		Students student=new Students();
		student.setStudentId(studentId);
		System.out.println("DAO"+studentId);
		WriteResult writeResult=mongoTemplate.remove(student);
		
		System.out.println(writeResult);
		int rowsAffected=(int) writeResult.getN();
		if(rowsAffected==0)
			return false;
		else
			return true;
	}

	@Override
	public boolean updateStudent(Students student) {
		Query query=new Query();
		query.addCriteria(Criteria.where("_id").is(student.getStudentId()));
		
		Update update=new Update();
		update.set("studentName", student.getStudentName());
		update.set("studentMarks", student.getStudentMarks());
		update.set("attendanceStatus", student.getAttendanceStatus());
		update.set("placement", student.getPlacement());
		
		WriteResult writeResult=mongoTemplate.updateFirst(query, update, Students.class);
		System.out.println(writeResult);
		int rowsAffected=(int) writeResult.getN();
		if (rowsAffected==0)
			return false;
		else
			return true;
	}
	
	

	@Override
	public List<Students> getAllStudents() {
		
		return mongoTemplate.findAll(Students.class);
	}

	@Override
	public List<Students> getStudentByName(String studentName) {
		Query query=new Query();
		query.addCriteria(Criteria.where("productName").is(studentName));
		
		List<Students> allStudentName=mongoTemplate.find(query, Students.class);
		//System.out.println(allProductName);
		return allStudentName;
	}

}
