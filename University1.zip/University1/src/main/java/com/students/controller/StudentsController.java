package com.students.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.students.model.Students;
import com.students.service.StudentService;

@RestController
@RequestMapping("student")
@CrossOrigin(origins= {"http://localhost:3000"})
public class StudentsController {
	
	@Autowired
	StudentService studentService;
	
	@GetMapping
	public ResponseEntity<List<Students>> getStudents()
	{
		System.out.println("get all students called");
		List<Students> allStudents=studentService.getAllStudents();
		return new ResponseEntity<List<Students>>(allStudents,HttpStatus.OK);
	}
	
	@GetMapping("/{studentId}") 
	public ResponseEntity<Students> getStudent(@PathVariable("studentId")int studentId) {
		System.out.println("get student called with "+studentId ); 
		Students student=new Students();
		if(studentService.isStudentExists(studentId)) {
		  student=studentService.getStudent(studentId);
		  System.out.println(student);
		  return new ResponseEntity<Students>(student,HttpStatus.OK);//200
		}
		else {
		  return new ResponseEntity<Students>(student,HttpStatus.NO_CONTENT);
		}
	  
	 }
	@DeleteMapping("/{studentId}")
	public ResponseEntity<String> deleteStudent(@PathVariable("studentId")int studentId){
		System.out.println("delete product called with"+studentId );
		if(studentService.isStudentExists(studentId)) {
			  studentService.deleteStudent(studentId);
			  return new ResponseEntity<String>("Student is deleted successsfully",HttpStatus.NO_CONTENT);
		  }
		  else {
			  return new ResponseEntity<String>("not found",HttpStatus.NOT_FOUND);//204
		  }
	 }
	
	@PostMapping
	public ResponseEntity<Students> addStudent(@RequestBody Students student)
	{
		System.out.println("saving with"+student);
		
		if(studentService.isStudentExists(student.getStudentId())) {
			return new ResponseEntity<Students>(student,HttpStatus.CONFLICT);//409
		}
		else {
			studentService.addStudent(student);
			return new ResponseEntity<Students>(student,HttpStatus.CREATED);//201
			
		}
	}
	
	@PutMapping
	public ResponseEntity<Students> updateStudent(@RequestBody Students student)
	{
		System.out.println("updating with"+student);
		
		if(studentService.isStudentExists(student.getStudentId())) {
			studentService.updateStudent(student);
			return new ResponseEntity<Students>(student,HttpStatus.OK);
		}
		else {
			
			return new ResponseEntity<Students>(student,HttpStatus.NO_CONTENT);//201
			
		}
	}
	@GetMapping("/searchStudent/{studentName}") 
	  public ResponseEntity<List<Students>>getStudentByName(@PathVariable("studentName")String studentName){
	  System.out.println("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%searchstudent by name"); 
	  List<Students> allStudents=studentService.getStudentByName(studentName);
	  System.out.println(allStudents);
		return new ResponseEntity<List<Students>>(allStudents, HttpStatus.OK);
	 }
	
	
	
	

}
