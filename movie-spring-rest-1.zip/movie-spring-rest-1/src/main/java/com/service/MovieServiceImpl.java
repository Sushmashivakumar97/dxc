package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.MovieDAO;
import com.model.Movie;

@Service
public class MovieServiceImpl implements MovieService {

	@Autowired
	MovieDAO movieDAO;

	@Override
	public boolean addMovie(Movie movie) {
		
		return movieDAO.addMovie(movie);
	}

	@Override
	public Movie getMovie(int movieId) {
		
		return movieDAO.getMovie( movieId);
	}

	@Override
	public List<Movie> allAllMovies() {
		
		return movieDAO.addAllMovie();
	}

	@Override
	public boolean deleteMovie(int movieId) {
		
		return movieDAO.deleteMovie(movieId);
	}

	@Override
	public boolean updateMovie(Movie movie) {
		
		return movieDAO.updateMovie(movie);
	}

	@Override
	public boolean isMovieExists(int movieId) {
		
		return false;
	}

}
