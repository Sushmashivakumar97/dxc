package com.service;

import java.util.List;

import com.model.Movie;

public interface MovieService {

	public boolean addMovie(Movie movie) ;

	public Movie getMovie(int movieId);
	
	public List<Movie> allAllMovies();

	public boolean deleteMovie(int movieId);

	public boolean updateMovie(Movie movie);
	
	public boolean isMovieExists(int movieId);

}
