package com.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import com.model.Movie;

@Repository
public class MovieDAOImpl implements MovieDAO {

	@Autowired
	MongoTemplate mongotemplate;

	@Override
	public boolean addMovie(Movie movie) {
		mongotemplate.save(movie);
		return false;
	}

	@Override
	public Movie getMovie(int movieId) {
		Movie m=mongotemplate.findById(movieId, Movie.class, "movie");
		return m;
	}

	@Override
	public List<Movie> addAllMovie() {
		List<Movie> l=mongotemplate.findAll(Movie.class, "movie");
		return l;
	}

	@Override
	public boolean deleteMovie(int movieId) {
		Movie movie=new Movie();
		movie.setMovieId(movieId);
		mongotemplate.remove(movie);
		return false;
	}

	@Override
	public boolean updateMovie(Movie movie) {
		mongotemplate.save(movie);
		return false;
	}

	
	

}
