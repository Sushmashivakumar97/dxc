package com.dxc.pms.dao;


import java.util.List;
import java.util.Set;

import com.dxc.pms.model.Product;
import com.dxc.pms.model.Review;

public interface ReviewDAO {

	public boolean addReview(Review review,int productId);
	public Set<Review> getAllReview(int productId);
	public boolean deleteReview(int reviewId, int productId);
	public boolean isReviewExists(int reviewId, int productId);
	
	public Review getReview(int reviewId, int productId);
	public boolean updateReview(int productId, Review review);

}
