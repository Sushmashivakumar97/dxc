package com.dxc.pms.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;


import org.springframework.data.annotation.Id;

@Entity
public class Review {

	
	@Id
	
	 //@GenericGenerator(name = "uuid", strategy = "uuid2")
	private int reviewId;
	private String reviewText;
	private int reviewRating;
	
	
   
	

	public Review() {
		
		// TODO Auto-generated constructor stub
	}

	public Review(int reviewId, String reviewText, int reviewRating) {
		super();
		this.reviewId = reviewId;
		this.reviewText = reviewText;
		this.reviewRating = reviewRating;
		
	}
	

	

	

	public int getReviewId() {
		return reviewId;
	}

	public void setReviewId(int reviewId) {
		this.reviewId = reviewId;
	}

	public String getReviewText() {
		return reviewText;
	}

	public void setReviewText(String reviewText) {
		this.reviewText = reviewText;
	}

	public int getReviewRating() {
		return reviewRating;
	}

	public void setReviewRating(int reviewRating) {
		this.reviewRating = reviewRating;
	}

	

	

	@Override
	public String toString() {
		return "Review [reviewId=" + reviewId + ", reviewText=" + reviewText + ", reviewRating=" + reviewRating
				+"]";
	}

	

}
