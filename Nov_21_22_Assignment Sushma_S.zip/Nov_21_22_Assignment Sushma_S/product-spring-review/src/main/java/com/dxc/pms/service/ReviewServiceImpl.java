package com.dxc.pms.service;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dxc.pms.dao.ReviewDAO;
import com.dxc.pms.model.Product;
import com.dxc.pms.model.Review;

@Service
public class ReviewServiceImpl implements ReviewService {

	@Autowired
	ReviewDAO reviewDAO;
	
	@Override
	public boolean addReview(Review review,int productId) {
		
		return reviewDAO.addReview(review,productId);
	}

	@Override
	public Set<Review> getAllReview(int productId) {
		
		return reviewDAO.getAllReview(productId);
	}

	@Override
	public boolean deleteReview(int reviewId, int productId) {
		// TODO Auto-generated method stub
		return reviewDAO.deleteReview(reviewId,productId);
	}

	@Override
	public boolean isReviewExists(int productId, int reviewId) {
		
		return reviewDAO.isReviewExists(reviewId,productId);
	}

	@Override
	public Review getReview(int productId, int reviewId) {
		
		return reviewDAO.getReview(reviewId,productId);
	}

	@Override
	public boolean updateReview(int productId, Review review) {
		
		return reviewDAO.updateReview(productId,review);
	}

}
