package com.controller;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.config.ResourceNotFoundException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dxc.pms.model.Product;
import com.dxc.pms.model.Review;
import com.dxc.pms.service.ProductService;
import com.dxc.pms.service.ReviewService;




@RestController
@CrossOrigin(origins= {"http://localhost:3000"})
@RequestMapping("product")
public class ReviewController {
	
	@Autowired
	ReviewService reviewService;
	
	@Autowired
	ProductService productService;
	
	
	@PostMapping("/{productId}/review")
	public ResponseEntity<Review> addReview(@PathVariable(value="productId")int productId,@RequestBody Review review)
	{
		System.out.println("saving with"+review);
		
		if(reviewService.isReviewExists(productId,review.getReviewId()))
		{
			return new ResponseEntity<Review>(HttpStatus.CONFLICT);
		}
		else {
			reviewService.addReview(review,productId);
			return new ResponseEntity<Review>(HttpStatus.CREATED);
		 
		}
	}
	
	
	@GetMapping("/{productId}/review")
	public ResponseEntity<Set<Review>> getAllReviews(@PathVariable("productId")int productId) {
		System.out.println("Get All reviews called");
		Set<Review>allreviews= reviewService.getAllReview(productId);
		return new ResponseEntity<Set<Review>>(allreviews,HttpStatus.OK);
	}
	
	@GetMapping("/{productId}/review/{reviewId}")
	public ResponseEntity<Review> getReview(@PathVariable("productId")int productId,@PathVariable("reviewId")int reviewId) {
		System.out.println("Get Reviews called "+reviewId);
		Review review=new Review();
		if(reviewService.isReviewExists(productId,reviewId))
		{
			System.out.println("not eneterd");
		review=reviewService.getReview(productId, reviewId);
		return new ResponseEntity<Review>(review,HttpStatus.OK);
		}
		else {
			System.out.println("entered");
			return new ResponseEntity<Review>(review,HttpStatus.NO_CONTENT);
		}
	}
	
	@DeleteMapping("/{productId}/review/{reviewId}")
	public ResponseEntity<String> deleteProduct(@PathVariable("productId")int productId,@PathVariable("reviewId")int reviewId)
	{
		
		if(reviewService.isReviewExists(productId, reviewId))
		{
			System.out.println("delete product called with"+productId );
			reviewService.deleteReview(reviewId, productId);
			return new ResponseEntity<String>("Review is deleted successsfully",HttpStatus.NO_CONTENT);
		}
		else {
			  return new ResponseEntity<String>("not found",HttpStatus.NOT_FOUND);//204
		  }
	}
	@PutMapping("/{productId}/review")
	public ResponseEntity<Review> updateReview(@PathVariable(value="productId")int productId,@RequestBody Review review)
	{
		System.out.println("updating with"+review);
		
		if(reviewService.isReviewExists(productId,review.getReviewId()))
		{
			reviewService.updateReview(productId,review);
			return new ResponseEntity<Review>(HttpStatus.CREATED);
		}
		else {
			
			return new ResponseEntity<Review>(HttpStatus.CONFLICT);
		}
	}
	
	
	
	

}
