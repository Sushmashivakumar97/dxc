import React, { Component } from 'react';
import { Formik, Form, Field,ErrorMessage  } from 'formik';
import ProductDataService from '../service/ProductDataService';

class ReviewComponent extends Component {
    constructor(props) {
        super(props);
        this.state={
            productId: this.props.match.params.productId,
            reviewId:this.props.match.params.reviewId,
            reviewText:'',
            reviewRating:'',
           btnTxt:'Add',
           disabled:false
        }
        this.submitReview=this.submitReview.bind(this);
        
    }
    componentWillMount()
    {
            if(this.state.reviewId){
                ProductDataService.getReview(this.state.productId,this.state.reviewId).then(response => {
                
                    this.setState({
                        reviewText: response.data.reviewText,
                        reviewRating: response.data.reviewRating,
                        btnTxt:'Update',
                        disabled:true
                    })
                })
            }
           else{
               return;
           }     
    }
    reviewFormValidation(values)
    {
        let errors={}
        if (!values.reviewId) {
            errors.reviewId = 'enter a reviewId'
        }
        else if (!values.reviewRating) {
            errors.reviewRating = 'please give rating'
        }
        else if(values.reviewRating==0)
        {
            errors.reviewRating='rating cannot be zero'
        }

        return errors
    }
    submitReview(review)
    {
        if(this.state.reviewId)
        {
            ProductDataService.updateReview(this.state.productId,review).then(response => { this.props.history.push("/products") })
        }
            
        else
            ProductDataService.addReview(this.state.productId,review).then(response=>this.props.history.push(`/products`)) 
    }
    
    render() {
        
        let {reviewId,reviewText,reviewRating}=this.state
        return (
            <div>
                <h1>Add/update</h1>
                <Formik
                initialValues={{reviewId,reviewText,reviewRating}}
                enableReinitialize={true}
                onSubmit={this.submitReview}
                validateOnBlur={false}
                validateOnChange={false}
                validate={this.reviewFormValidation}>
                    <Form>
                            <ErrorMessage name="reviewId" component="div" className="alert alert-warning" />
                            <ErrorMessage name="reviewRating" component="div" className="alert alert-warning" />
                        <fieldset className="form-group">
                            <label>reviewId</label>
                            <Field className="form-control" type="text" name="reviewId" disabled={this.state.disabled}></Field>
                        </fieldset>
                        <fieldset className="form-group">
                            <label>comment</label>
                            <Field className="form-control" type="text" name="reviewText"></Field>
                        </fieldset>
                        <fieldset className="form-group">
                            <label>rating</label>
                            <Field className="form-control" type="text" name="reviewRating"></Field>
                        </fieldset>
        <button className="btn btn-success" type="submit">{this.state.btnTxt}</button>
                    </Form>

                </Formik>
            </div>
        );
    }
}

export default ReviewComponent;