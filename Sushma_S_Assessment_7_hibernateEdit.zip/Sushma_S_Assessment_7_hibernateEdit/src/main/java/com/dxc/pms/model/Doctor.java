package com.dxc.pms.model;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

import org.hibernate.search.annotations.IndexedEmbedded;

@NamedQueries({
	@NamedQuery(
			name="findDoctorByName",
			query="from Doctor d where d.doctorName=:dd")
})

@Entity //collection name is Product.. if we dont specify table name, it takes Product
public class Doctor {
	@Id
	private int doctorId;
	@Column(name="DoctorName")
	private String doctorName;
	@Column(name="Fees")
	private int doctorFees;
	@ElementCollection
	@IndexedEmbedded
	private Set<HospitalDetails>hospitalDetails ;
	
	

	public Doctor() {
		
	}



	public Doctor(int doctorId, String doctorName, int doctorFees, Set<HospitalDetails> hospitalDetails) {
		super();
		this.doctorId = doctorId;
		this.doctorName = doctorName;
		this.doctorFees = doctorFees;
		this.hospitalDetails = hospitalDetails;
	}



	public int getDoctorId() {
		return doctorId;
	}



	public void setDoctorId(int doctorId) {
		this.doctorId = doctorId;
	}



	public String getDoctorName() {
		return doctorName;
	}



	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}



	public int getDoctorFees() {
		return doctorFees;
	}



	public void setDoctorFees(int doctorFees) {
		this.doctorFees = doctorFees;
	}



	public Set<HospitalDetails> getHospitalDetails() {
		return hospitalDetails;
	}



	public void setHospitalDetails(Set<HospitalDetails> hospitalDetails) {
		this.hospitalDetails = hospitalDetails;
	}



	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + doctorFees;
		result = prime * result + doctorId;
		result = prime * result + ((doctorName == null) ? 0 : doctorName.hashCode());
		result = prime * result + ((hospitalDetails == null) ? 0 : hospitalDetails.hashCode());
		return result;
	}



	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Doctor other = (Doctor) obj;
		if (doctorFees != other.doctorFees)
			return false;
		if (doctorId != other.doctorId)
			return false;
		if (doctorName == null) {
			if (other.doctorName != null)
				return false;
		} else if (!doctorName.equals(other.doctorName))
			return false;
		if (hospitalDetails == null) {
			if (other.hospitalDetails != null)
				return false;
		} else if (!hospitalDetails.equals(other.hospitalDetails))
			return false;
		return true;
	}



	@Override
	public String toString() {
		return "Doctor [doctorId=" + doctorId + ", doctorName=" + doctorName + ", doctorFees=" + doctorFees
				+ ", hospitalDetails=" + hospitalDetails + "]";
	}
	


	
	
	
}
