package com.dxc.pms.dao;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.dxc.pms.model.Doctor;
import com.dxc.pms.model.HospitalDetails;


import junit.framework.TestCase;

public class DoctorDAOImplTest extends TestCase {
	DoctorDAOImpl impl;
	protected void setUp() throws Exception {
		impl=new DoctorDAOImpl();
	}

	protected void tearDown() throws Exception {
		super.tearDown();
	}

	public void testGetDoctor() {
		HospitalDetails hd=new HospitalDetails("kims","Bengaluru");
		  Set<HospitalDetails> hds=new HashSet<HospitalDetails>(); 
		  hds.add(hd); 
		  Doctor doctor=new Doctor(1067,"Shilpa",350,hds); impl.addDoctor(doctor);		 
        Doctor d=impl.getDoctor(1067);
        assertNotNull(d);
        impl.deleteDoctor(1067);
	}

	public void testGetAllDoctor() {
		int size1=impl.getAllDoctor().size();
		HospitalDetails hd=new HospitalDetails("kims","Bengaluru");
        Set<HospitalDetails> hds=new HashSet<HospitalDetails>();
        hds.add(hd);
        Doctor doctor=new Doctor(100,"Sheela",350,hds);
		 impl.addDoctor(doctor);
        int size2=impl.getAllDoctor().size();
        assertNotSame(size2,size1);
        impl.deleteDoctor(100);
	}

	public void testAddDoctor() {
		List <Doctor>alldoctor1=impl.getAllDoctor(); 
		  HospitalDetails hd=new HospitalDetails("kanva", "bang");
		  Set<HospitalDetails> hds=new HashSet<HospitalDetails>(); 
		  hds.add(hd);
		  Doctor doctor=new Doctor(10, "megha", 100, hds); 		  
		  impl.addDoctor(doctor);
		  List <Doctor>alldoctor2=impl.getAllDoctor(); 
		  assertNotSame(alldoctor1.size(),alldoctor2.size());
		  
		 
	}

	public void testDeleteDoctor() {
		 
		  HospitalDetails hd=new HospitalDetails("kanva", "bang");
		  Set<HospitalDetails> hds=new HashSet<HospitalDetails>(); 
		  hds.add(hd);
		  Doctor doctor=new Doctor(10, "megha", 100, hds); 		  
		  impl.addDoctor(doctor);
		  List <Doctor>alldoctor1=impl.getAllDoctor();
		  impl.deleteDoctor(10);
		  List <Doctor>alldoctor2=impl.getAllDoctor();
		  assertNotSame(alldoctor1, alldoctor2);
        
	}

	public void testUpdateDoctor() {
		
		 HospitalDetails hd1=new HospitalDetails("kanva", "bang");
		  Set<HospitalDetails> allHd=new HashSet<HospitalDetails>(); 
		  allHd.add(hd1);
		  Doctor doctor1=new Doctor(98, "m", 100, allHd);
		  impl.addDoctor(doctor1);
		  List <Doctor> alldoctor1=impl.getAllDoctor();
		  HospitalDetails hd2=new HospitalDetails("kanva", "bang");
		  Set<HospitalDetails> allHd2=new HashSet<HospitalDetails>(); 
		  allHd2.add(hd2);
		  Doctor doctor2=new Doctor(98, "m11", 100, allHd);
		  impl.updateDoctor(doctor1);
		  List <Doctor> alldoctor2=impl.getAllDoctor();
		  assertNotSame(alldoctor1,alldoctor2);
		  impl.deleteDoctor(98);
	}

	public void testIsDoctorExists() {
		 HospitalDetails hd1=new HospitalDetails("kanva", "bang");
		  Set<HospitalDetails> allHd=new HashSet<HospitalDetails>(); 
		  allHd.add(hd1);
		  Doctor doctor=new Doctor(678, "megha", 100, allHd); 
		  impl.addDoctor(doctor);
		 assertEquals(true,impl.isDoctorExists(678));
		 impl.deleteDoctor(678);
		 
	}

	public void testGetAllDoctorString() {
		List <Doctor> alldoctor1=impl.getAllDoctor("megha");
		List <Doctor> alldoctor2=impl.getAllDoctor("Random");
		assertNotSame(alldoctor1, alldoctor2);
		
		
	}

}
