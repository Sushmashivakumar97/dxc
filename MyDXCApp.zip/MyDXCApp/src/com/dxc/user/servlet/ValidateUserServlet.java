package com.dxc.user.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dxc.user.dao.UserFormDAO;
import com.dxc.user.dao.UserFormDAOImpl;
//import com.dxc.user.model.UserForm;

/**
 * Servlet implementation class ValidateUserServlet
 */
@WebServlet("/ValidateUserServlet")
public class ValidateUserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ValidateUserServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String uName=request.getParameter("userName");
		String pwd=request.getParameter("password");
		
		//UserForm userform = new UserForm();
		UserFormDAO userFormDAO = new UserFormDAOImpl();
		if(userFormDAO.validateUser(uName,pwd))
		{
			response.getWriter().println("<h1>You logged in successfully");
		}
		else
		{
			response.getWriter().println("<h1>user name or password is incorrect. Retry");
			response.sendRedirect("loginform.html");
		}
		
		response.getWriter().println("<h1><a href='Index.html'>Home</a></h1><br>");
		response.getWriter().println("<h1><a href='registrationform.html'>Register</a></h1>");
			
	}

}
