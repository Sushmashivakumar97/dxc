package com.dxc.user.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.dxc.pms.dbcon.DBConnection;
import com.dxc.user.model.UserForm;



public class UserFormDAOImpl implements UserFormDAO {
	
	Connection connection=DBConnection.getConnection();

	public UserFormDAOImpl() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void addUser(UserForm userform) {
		try {
			PreparedStatement preparedStatement;
			preparedStatement=connection.prepareStatement("insert into userform value(?,?,?,?,?)");
			preparedStatement.setString(1, userform.getUserName());
			preparedStatement.setString(2, userform.getPassword());
			preparedStatement.setString(3, userform.getFullName());
			preparedStatement.setString(4, userform.getGender());
			preparedStatement.setString(5, userform.getQualification());
			
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public boolean validateUser(String userName, String password) {
		boolean userExists=false;
		PreparedStatement preparedStatement;
		
		try {
			preparedStatement=connection.prepareStatement("select * from userform where userName=? and password=?");
			preparedStatement.setString(1, userName);
			preparedStatement.setString(2, password);
			ResultSet res=preparedStatement.executeQuery();
			if(res.next())
			{
				userExists=true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return userExists;
	}

}
