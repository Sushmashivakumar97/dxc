package com.dxc.user.dao;

import com.dxc.user.model.UserForm;

public interface UserFormDAO {
	public void addUser(UserForm userform);
	public boolean validateUser(String userName,String password); 
}
