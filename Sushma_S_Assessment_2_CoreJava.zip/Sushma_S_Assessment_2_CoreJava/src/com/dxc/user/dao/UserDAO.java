package com.dxc.user.dao;


import com.dxc.user.model.Users;

public interface UserDAO {
	//public void getUser(Users users);
	public boolean isUserExists(String userName, String passWord);
	
	//public Users getUser(Users users);
}
