package com.dxc.user.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.dxc.user.dbcon.DBConnection;

public  class UserDAOimpl implements UserDAO {
	Connection connection=DBConnection.getConnection();

	public UserDAOimpl() {
		// TODO Auto-generated constructor stub
	}
//####################################################
	
//##########################################

	@Override
	public boolean isUserExists(String userName, String passWord) {
		boolean userExists=false;
		PreparedStatement preparedStatement;
		
		try {
			preparedStatement=connection.prepareStatement("select* from users where userName=? and passWord=?");
			preparedStatement.setString(1, userName);
			preparedStatement.setString(2, passWord);
			ResultSet res=preparedStatement.executeQuery();
			if(res.next())
			{
				userExists=true;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return userExists;
	}

	
	


	
	}



	
	


