package com.dxc.user.client;

import java.util.Scanner;

import com.dxc.training.dao.TrainingDAO;
import com.dxc.training.dao.TrainingDAOImpl;
import com.dxc.user.dao.UserDAO;
import com.dxc.user.dao.UserDAOimpl;

public class DxcApp {
	UserDAO userDAO =new UserDAOimpl();
	TrainingDAO trainingDAO=new TrainingDAOImpl();
	
	String userName;
	String passWord;
	
	Scanner sc=new Scanner(System.in);

	public DxcApp() {
		
	}
	public void launchDXCApp()
	{
		while(true)
		{
			System.out.println("menu");
			System.out.println("1. search users");
			System.out.println("2.get all trainee details");
			System.out.println("3.update percentage");
			System.out.println("enter choice");
			int choice=sc.nextInt();
			
			switch(choice)
			{
			case 1:System.out.println("please enter username and passwrod to search");
			userName=sc.next();
			passWord=sc.next();
			
			
			
			if(userDAO.isUserExists(userName, passWord))
				
			{
				
				System.out.println("User successfully authenticated ");
			}
			else 
			{
				System.out.println("sorry cannot be authenticated");
			}
			break;
			
			case 2:System.out.println("details of all the trainee are displayed below");
			System.out.println(trainingDAO.getAllTrainee());
			break;
			
			case 3:trainingDAO.getTrainee();
				
			}
			
			
		}
		
		
		
		
		
		
		
		//System.out.println(trainingDAO.getAllTrainee());
		
		
	}

}
