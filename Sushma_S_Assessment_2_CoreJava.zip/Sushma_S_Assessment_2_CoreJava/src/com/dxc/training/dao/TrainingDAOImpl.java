package com.dxc.training.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.dxc.training.model.Training;
import com.dxc.user.dbcon.DBConnection;


public class TrainingDAOImpl implements TrainingDAO {
	Connection connection=DBConnection.getConnection();

	public TrainingDAOImpl() {
		// TODO Auto-generated constructor stub
	}
//###############################################################################
	@Override
	public List<Training> getAllTrainee()
	{
		List<Training> allTrainee=new ArrayList<Training>();
		
		try {
			Statement stat=connection.createStatement();
			ResultSet res=stat.executeQuery("select * from training");
			
			while(res.next())
			{
				Training training=new Training();
				training.setSapId(res.getInt(1));
				training.setEmployeeName(res.getString(2));
				training.setStream(res.getString(3));
				training.setPercentage(res.getInt(4));
				allTrainee.add(training);
				
				
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return allTrainee;
	}
//####################################################################################
	
	public void  getTrainee()
	{
		try {
			Statement stat =connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
			                ResultSet.CONCUR_UPDATABLE);
      
			ResultSet res = stat.executeQuery("select * from training");
			//ResultSetMetaData rsmd = res.getMetaData();
			
	   
	        res.beforeFirst();
	       
	        
	        while(res.next())
	        { 
	        	for (int i = 1; i <= 3; i++)
	        	{
	        		System.out.println(res.getString(i) + " ");
	        		
	        	} 
	        	Scanner sc=new Scanner(System.in);
        		System.out.println("enter percentage");
        		int percentage=sc.nextInt();
        		res.updateInt(4, percentage);
        		res.updateRow();
        		
        		        		
	        	
	        }
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
       
        
	}

	
	
	}


