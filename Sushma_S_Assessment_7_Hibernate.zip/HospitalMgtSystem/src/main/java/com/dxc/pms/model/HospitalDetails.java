package com.dxc.pms.model;

import javax.persistence.Embeddable;

@Embeddable
public class HospitalDetails {
	
	private String hospitalName;
	private String hospitalDetails;
	
	public  HospitalDetails() {
		// TODO Auto-generated constructor stub
	}

	public HospitalDetails(String hospitalName, String hospitalDetails) {
		super();
		this.hospitalName = hospitalName;
		this.hospitalDetails = hospitalDetails;
	}

	public String getHospitalName() {
		return hospitalName;
	}

	public void setHospitalName(String hospitalName) {
		this.hospitalName = hospitalName;
	}

	public String getHospitalDetails() {
		return hospitalDetails;
	}

	public void setHospitalDetails(String hospitalDetails) {
		this.hospitalDetails = hospitalDetails;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((hospitalDetails == null) ? 0 : hospitalDetails.hashCode());
		result = prime * result + ((hospitalName == null) ? 0 : hospitalName.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		HospitalDetails other = (HospitalDetails) obj;
		if (hospitalDetails == null) {
			if (other.hospitalDetails != null)
				return false;
		} else if (!hospitalDetails.equals(other.hospitalDetails))
			return false;
		if (hospitalName == null) {
			if (other.hospitalName != null)
				return false;
		} else if (!hospitalName.equals(other.hospitalName))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "HospitalDetails [hospitalName=" + hospitalName + ", hospitalDetails=" + hospitalDetails + "]";
	}
	
	

}
