package com.dxc.pms.util;

import org.hibernate.SessionFactory;
import org.hibernate.ogm.cfg.OgmConfiguration;

public class HibernateUtil {
	
	public static SessionFactory getSessionFactory() {

		//  configuration object:It represents a configuration or properties file required by the Hibernate.
		/*
		 * The Configuration object provides two keys components −
		 * 
		 * Database Connection − This is handled through one or more configuration files
		 * supported by Hibernate. These files are hibernate.properties and
		 * hibernate.cfg.xml.
		 * 
		 * Class Mapping Setup − This component creates the connection between the Java
		 * classes and database tables.
		 */
		OgmConfiguration config =new OgmConfiguration();
		config.configure();
		
		/*
		 * SessionFactory Object: Configuration object is used to create a SessionFactory
		 * object which in turn configures Hibernate for the application using the
		 * supplied configuration file and allows for a Session object to be
		 * instantiated. The SessionFactory is a thread safe object and used by all the
		 * threads of an application.
		 * 
		 * The SessionFactory is a heavyweight object; it is usually created during
		 * application start up and kept for later use. You would need one
		 * SessionFactory object per database using a separate configuration file. So,
		 * if you are using multiple databases, then you would have to create multiple
		 * SessionFactory objects.
		 */
		SessionFactory factory=config.buildSessionFactory();
		return factory;
	
	}		

}
