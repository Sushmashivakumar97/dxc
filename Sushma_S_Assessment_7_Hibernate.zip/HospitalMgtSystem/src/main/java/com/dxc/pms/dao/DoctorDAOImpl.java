package com.dxc.pms.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.dxc.pms.model.Doctor;

import com.dxc.pms.util.HibernateUtil;

public class DoctorDAOImpl implements DoctorDAO {

	SessionFactory sf= HibernateUtil.getSessionFactory();
	
	@Override
	public Doctor getDoctor(int doctorId) {
		Session session=sf.openSession();
		Doctor doctor=(Doctor) session.get(Doctor.class,doctorId); //will link to the row
		return doctor;
	}

	@Override
	public List<Doctor> getAllDoctor() {
		Session session=sf.openSession();
		Query query=session.createQuery("from Doctor");
		return query.list();
	}

	@Override
	public void addDoctor(Doctor doctor) {
		Session session=sf.openSession();
		Transaction transaction= session.beginTransaction();
		session.save(doctor);
		transaction.commit();
		session.close();
		System.out.println(doctor.getDoctorName()+" saved successfully");
	}

	@Override
	public void deleteDoctor(int doctorId) {
		Session session=sf.openSession();
		Transaction transaction= session.beginTransaction();
		Doctor doctor=new Doctor(); doctor.setDoctorId(doctorId);
		session.delete(doctor);
		transaction.commit();
		session.close();

	}

	@Override
	public void updateDoctor(Doctor newdoctor) {
		Session session=sf.openSession();
		Transaction transaction= session.beginTransaction();
		session.update(newdoctor);
		transaction.commit();
		session.close();

	}

	@Override
	public boolean isDoctorExists(int doctorId) {
		Session session=sf.openSession();
		Doctor doctor=(Doctor) session.get(Doctor.class,doctorId);
		if(doctor==null)
			return false;
		else
			return true;
	}

	

	@Override
	public List<Doctor> getAllDoctor(String doctorName) {
		Session session=sf.openSession();
		Query query=session.getNamedQuery("findDocotrByName");
		query.setString("pp", doctorName);
		return query.list();
	}

}
