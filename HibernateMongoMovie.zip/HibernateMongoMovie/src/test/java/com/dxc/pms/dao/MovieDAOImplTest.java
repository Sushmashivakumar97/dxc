package com.dxc.pms.dao;

import java.util.List;

import com.dxc.pms.model.Movie;

import junit.framework.TestCase;

public class MovieDAOImplTest extends TestCase {
MovieDAOImpl impl;
	protected void setUp() throws Exception {
		impl=new MovieDAOImpl();
	}

	protected void tearDown() throws Exception {
		super.tearDown();
	}

	public void testGetMovie() {
		
        Movie movie2 =impl.getMovie(30);
        assertNotNull(movie2);
	}

	public void testGetAllMovie() {
		int size1=impl.getAllMovie().size();
        Movie movie =new Movie(901, "nota", 23, "m");
        impl.addMovie(movie);
        int size2=impl.getAllMovie().size();
        assertNotSame(size2,size1);
	}

	public void testAddMovie() {
		Movie movie =new Movie(587, "phone", 23, "s");
        List <Movie> allmovie1=impl.getAllMovie();
        impl.addMovie(movie);
        List <Movie> allmovie2=impl.getAllMovie();
        assertNotSame(allmovie1.size(), allmovie2.size());
	}

	public void testDeleteMovie() {
		
        int size1=impl.getAllMovie().size();
        impl.deleteMovie(30);
        int size2=impl.getAllMovie().size();
        assertEquals(size2+1,size1);
	}

	public void testUpdateMovie() {
		
        List <Movie> allmovie1=impl.getAllMovie();
        Movie newmovie =new Movie(3000, "syra", 23, "s");
        impl.updateMovie(newmovie);
        List <Movie> allmovie2=impl.getAllMovie();
       
        assertNotSame(allmovie1,allmovie2);
	}

	public void testIsMovieExists1() {
		
        assertEquals(true,impl.isMovieExists(1));
    }
    public void testIsProductExists2() {
        
        impl.deleteMovie(100957);
        assertEquals(false,impl.isMovieExists(100957));
    }

}
