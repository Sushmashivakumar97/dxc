var fs=require("fs")
var express = require("express")
var app = express()
app.set('view engine', 'ejs')
app.use('/assets', express.static("assets"));

 /* 
 var message=fs.readFileSync("./resources/about.txt")
 fs.appendFile( './views/about.ejs',message, function (err) {
    if (err) throw err;
      console.log('Saved!');
    });
 app.get("/",function (request, response) {
    response.render("about") 
})  */

var data
fs.readFile( './resources/about.txt', function (err,d) {
    if (err) 
      console.log(err.message);
    else
      data=d
  });
app.get("/",function (request, response) {
   response.render("about",{sendData:data}) 
})

console.log("server started on port:5001")
app.listen(5001);


