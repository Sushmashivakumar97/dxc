package com.dxc.client;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.ogm.cfg.OgmConfiguration;

import com.dxc.model.Customer;
import com.dxc.model.Employee;


public class App 
{
    public static void main( String[] args )
    {
        OgmConfiguration cfg=new OgmConfiguration();
        cfg.configure();
        
        SessionFactory factory=cfg.buildSessionFactory();
        Session session=factory.openSession();
		/*
		 * openSession() method always opens a new session. We should close this session
		 * object once we are done with all the database operations.
		 */

        
        Transaction transaction=session.beginTransaction();
        
		/* Employee employee=new Employee(19187,"Swathi","Pune",96000); */
		/* Employee employee=new Employee(19188,"Sush","Pune",95000); */
        
       // session.save(employee);
        
		/* Customer customer=new Customer(101,"Suresh","Bang",800); */
        Customer customer=new Customer(102,"muresh","Bang",800);
        Customer customer1=new Customer(103,"buresh","Bang",800);
        
        session.save(customer);
        session.save(customer1);
        
        transaction.commit();
        System.out.println("data is stored");
        
    }
}
