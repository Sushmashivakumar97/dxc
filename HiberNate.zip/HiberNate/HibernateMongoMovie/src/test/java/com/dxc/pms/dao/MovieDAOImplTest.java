package com.dxc.pms.dao;

import java.util.List;

import com.dxc.pms.model.Movie;

import junit.framework.TestCase;

public class MovieDAOImplTest extends TestCase {
MovieDAOImpl impl;
	protected void setUp() throws Exception {
		impl=new MovieDAOImpl();
	}

	protected void tearDown() throws Exception {
		super.tearDown();
	}

	public void testGetMovie() {
		if(impl.isMovieExists(3000));
        	Movie movie2 =impl.getMovie(3000);
        assertNotNull(movie2);
	}

	public void testGetAllMovie() {
		int size1=impl.getAllMovie().size();
        Movie movie =new Movie(9011, "nota", 23, "m");
        impl.addMovie(movie);
        int size2=impl.getAllMovie().size();
        assertNotSame(size2,size1);
	}

	public void testAddMovie() {
		Movie movie =new Movie(5887, "kesari", 23, "s");
        List <Movie> allmovie1=impl.getAllMovie();
        impl.addMovie(movie);
        List <Movie> allmovie2=impl.getAllMovie();
        assertNotSame(allmovie1.size(), allmovie2.size());
	}

	public void testDeleteMovie() {
		
        int size1=impl.getAllMovie().size();
        if(impl.isMovieExists(100956));
        	impl.deleteMovie(100956);
        int size2=impl.getAllMovie().size();
        assertEquals(size2+1,size1);
	}

	public void testUpdateMovie() {
		
        List <Movie> allmovie1=impl.getAllMovie();
        Movie newmovie =new Movie(2, "black", 23, "s");
        if(impl.isMovieExists(2));
        impl.updateMovie(newmovie);
        List <Movie> allmovie2=impl.getAllMovie();
       
        assertNotSame(allmovie1,allmovie2);
	}

	public void testIsMovieExists1() {
		
        assertEquals(true,impl.isMovieExists(20));
    }
    public void testIsProductExists2() {
        
        impl.deleteMovie(100957);
        assertEquals(false,impl.isMovieExists(100957));
    }

}
