package com.dxc.pms.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.dxc.pms.model.Movie;

import com.dxc.pms.util.HibernateUtil;


public class MovieDAOImpl implements MovieDAO {

	SessionFactory sf= HibernateUtil.getSessionFactory();
	
	public Movie getMovie(int movieId) {
		Session session=sf.openSession();
		Movie movie=(Movie) session.get(Movie.class,movieId); //will link to the row
		return movie;
	}

	public List<Movie> getAllMovie() {
         Session session=sf.openSession();
         Query query=session.createQuery("from Movie"); //here Movie is classname not table name
		return query.list();
	}

	public void addMovie(Movie movie) {
		Session session=sf.openSession();
		Transaction transaction=session.beginTransaction();
		session.save(movie);
		transaction.commit();
		session.close();
		System.out.println(movie.getMovieName()+" saved successfully");

	}

	public void deleteMovie(int movieId) {
		Session session=sf.openSession();
		Transaction transaction= session.beginTransaction();
		Movie movie=new Movie();
		movie.setMovieId(movieId);
		session.delete(movie);
		transaction.commit();
		session.close();
	}

	public void updateMovie(Movie newmovie) {
		Session session=sf.openSession();
		Transaction transaction= session.beginTransaction();
		session.update(newmovie);
		transaction.commit();
		session.close();

	}

	public boolean isMovieExists(int movieId) {
		Session session=sf.openSession();
		Movie movie=(Movie) session.get(Movie.class,movieId);
		if(movie==null)
			return false;
		else
			return true;
	}

}
