package com.entity;

import org.hibernate.SessionFactory;
import org.hibernate.ogm.cfg.OgmConfiguration;

public class HibernateUtil {
	
	public static SessionFactory getSessionFactory() {

		OgmConfiguration config =new OgmConfiguration();
		config.configure();
		SessionFactory factory=config.buildSessionFactory();
		return factory;
	
	}		

}
