package com.dxc.pms.dao;

import java.util.List;

import com.dxc.pms.model.Product;

import junit.framework.TestCase;

public class ProductDAOImplTest3 extends TestCase {

	ProductDAOImpl impl;
	protected void setUp() throws Exception {
		impl=new ProductDAOImpl();
	}

	protected void tearDown() throws Exception {
		super.tearDown();
	}

	public void testGetAllProduct() {
		List<Product> p= impl.getAllProduct("phone");
		System.out.println(p);
		assertEquals(p.size(),5);
	}

}
