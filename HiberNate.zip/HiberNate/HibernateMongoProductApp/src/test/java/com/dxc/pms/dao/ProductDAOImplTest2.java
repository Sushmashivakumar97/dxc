package com.dxc.pms.dao;

import java.util.List;

import junit.framework.TestCase;

public class ProductDAOImplTest2 extends TestCase {

	ProductDAOImpl impl;
	
	protected void setUp() throws Exception {
		impl= new ProductDAOImpl();
	}

	protected void tearDown() throws Exception {
		super.tearDown();
	}

	public void testGetAllProductName() {
		List<String> all=impl.getAllProductName();
		assertEquals(all.size(), 8);
	}
	
	

}
