package com.dxc.pms.client;

public class Main {

	public Main() {
		// TODO Auto-generated constructor stub
	}
	public static void main(String[] args) {
		ProductApp app =new ProductApp();
		app.launchProductApp();
	}

}
