package com.dxc.pms.client;

import java.util.Scanner;

import com.dxc.pms.dao.ProductDAO;
import com.dxc.pms.dao.ProductDAOImpl;
import com.dxc.pms.model.Product;

public class ProductApp {
	
	ProductDAO productDao;
	
	int productId;
	String productName;
	int quantityOnHand;
	int price;
	
	Scanner scanner =new Scanner(System.in);

	public ProductApp() {
		this.productDao=new ProductDAOImpl();
	}
	public void launchProductApp() {
		
		while(true)
		{
			
			
			System.out.println("M E N U ");
            System.out.println("1. Add The products : ");
            System.out.println("2. Get All The products : ");
            System.out.println("3. Get The products by id: ");
            System.out.println("4. delete The products by id: ");
            System.out.println("5. update The products : ");
            System.out.println("6. E X I T");
            
            int choice = 0;
            System.out.println("Please enter your choice : (1-6)");
            choice = scanner.nextInt();
            
            switch(choice)
            {
            case 1:
            	Product product = takeProductInput();
            	if(!productDao.isProductExists(product.getProductId()))
            	{
            		productDao.addProduct(product);
            	}
            	else
            	{
            		System.out.println("product already exists with same product Id");
            	}
            	 
                
                break;
                
            case 2:
                System.out.println(productDao.getAllProduct());
                break;
            case 3:
            	System.out.println("Please enter product id to search :");
            	productId = scanner.nextInt();
            	
            	if (productDao.isProductExists(productId)) {
					Product searchedProduct = productDao.getProduct(productId);
					System.out.println(searchedProduct);
				}
            	else
            	{
            		System.out.println("product id not found");
            	}
				break;
            case 4:
            	System.out.println("Please enter product id to delete :");
            	productId = scanner.nextInt();
            	
            	 if (productDao.isProductExists(productId)) {
					productDao.deleteProduct(productId);
					System.out.println("product successfully deleted");
				}
            	 else
            	 {
            		 System.out.println("product id not found");
            	 }
				break;
            case 5:
            	System.out.println("welcome to app category");
            	Product productToUpdate = takeProductInput();
            	if (productDao.isProductExists(productToUpdate.getProductId())) {
					
					productDao.updateProduct(productToUpdate);
					System.out.println("your product updated successfully");
				}
				break;
                
            case 6:
                System.out.println("Thanks for using my app");
                System.exit(0);
            default:
                System.out.println("R U drunk milk. Please enter (1-3)");
            }
 
		}
	}
	private Product takeProductInput() {
		System.out.println("Please enter product id :");
		productId = scanner.nextInt();
		System.out.println("Please enter product name :");
		 productName = scanner.next();
		System.out.println("Please enter product quantity :");
		 quantityOnHand = scanner.nextInt();
		System.out.println("Please enter product price :");
		 price = scanner.nextInt();
		
		Product product = new Product(productId, productName, quantityOnHand, price);
		return product;
	}

}
