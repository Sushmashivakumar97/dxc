package com.dxc.pms.dao;

import java.util.List;

import com.dxc.pms.model.Product;

public interface ProductDAO {

	public Product getProduct(int productId);
	public List<Product> getAllProduct();
	public void addProduct(Product product);
	public void deleteProduct(int productId);
	public void updateProduct(Product product);
	public boolean isProductExists(int productId);
	
	public List<String> getAllProductName();
	public List<Product> getAllProduct(String productName);
}
