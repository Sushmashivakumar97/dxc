package com.dxc.pms.dao;//new>class>add>ProductDAO>className>ProductDAOImpl 

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.dxc.pms.model.Product;
import com.dxc.pms.util.HibernateUtil;

public class ProductDAOImpl implements ProductDAO {

	SessionFactory sf= HibernateUtil.getSessionFactory();
	
	@Override
	public Product getProduct(int productId) {
		/*
		 * A Session is used to get a physical connection with a database. The Session
		 * object is lightweight and designed to be instantiated each time an
		 * interaction is needed with the database. Persistent objects are saved and
		 * retrieved through a Session object.
		 * 
		 * The session objects should not be kept open for a long time because they are
		 * not usually thread safe and they should be created and destroyed them as
		 * needed.
		 */
		
		Session session=sf.openSession();
		Product product=(Product) session.get(Product.class,productId); //will link to the row
		return product;
	}

	@Override
	public List<Product> getAllProduct() {
		Session session=sf.openSession();
		Query query=session.createQuery("from Product");
		return query.list();
	}
	//Java way of retrieving data (use in oracle and mysql)
	
	//Criteria c=session.createCriteria(Product.class)
	//criteria.list()
	//c.add(Restriction.between("price",400,500))
	//criteria.list()
	
	@Override
	public List<String> getAllProductName() {
		Session session=sf.openSession();
		Query query=session.createQuery("select productName from Product");
		//Query query=session.createQuery("select productName from Product where price>500");
		//Query query=session.createQuery("select count(price) from Product");use can use min,sum,max
		List<String> pr=query.list();
		Iterator<String> i=pr.iterator();
		
		while(i.hasNext()) {
			String p=i.next();
			System.out.println(p);
		}
		return pr;
	}

	@Override
	public void addProduct(Product product) {
		Session session=sf.openSession();
		Transaction transaction= session.beginTransaction();
		session.save(product);
		transaction.commit();
		session.close();
		System.out.println(product.getProductName()+" saved successfully");
		
	}

	@Override
	public void deleteProduct(int productId) {
		Session session=sf.openSession();
		Transaction transaction= session.beginTransaction();
		Product product=new Product(); product.setProductId(productId);
		session.delete(product);
		//Product product=(Product)session.delete(Movie.class, productId);
		transaction.commit();
		session.close();
		
	}

	@Override
	public void updateProduct(Product newproduct) {
		Session session=sf.openSession();
		Transaction transaction= session.beginTransaction();
		session.update(newproduct);
		/*
		 * Product oldproduct=(Product)
		 * session.get(Product.class,newproduct.getProductId());
		 * oldproduct.setProductName(newproduct.getProductName());
		 * oldproduct.setQuantityOnHand(newproduct.getQuantityOnHand());
		 * oldproduct.setPrice(newproduct.getPrice());
		 */
		transaction.commit();
		session.close();
				
		
	}

	@Override
	public boolean isProductExists(int productId) {
		Session session=sf.openSession();
		Product product=(Product) session.get(Product.class,productId);
		if(product==null)
			return false;
		else
			return true;
	}

	//Named Query: u can use it in other DAOImpl
	@Override
	public List<Product> getAllProduct(String productName) {
		Session session=sf.openSession();
		//Query query=session.createQuery("select * from Product where productName ");
		Query query=session.getNamedQuery("findProductByName");
		query.setString("pp", productName);
		return query.list();
	}
	
	
	
	
	
	
}
